require('dotenv').config();

const { askIfContinue } = require('./lib/ask.js');
const jobcan = new (require('./model/jobcan.js'))();
const jira = new (require('./model/jira.js'))();
const colors = require('colors/safe');
const moment = require('moment-timezone');

function getDateRange(startDate, endDate) {
  let timeMin = startDate ? moment(startDate).toISOString() : moment().subtract(1, 'day').startOf('day').toISOString();
  let timeMax = endDate ? moment(endDate).toISOString() : moment().subtract(1, 'day').endOf('day').toISOString();

  return { timeMin, timeMax };
}

async function main(startDate, endDate) {
  const output = process.env.OUTPUT.toUpperCase();
  const { timeMin, timeMax } = getDateRange(startDate, endDate);

  console.log(colors.bold(`\n🤖 Locale ${moment.locale()}, timezone ${moment().format('Z')}`));
  console.log(colors.bold(`Search between ${colors.blue(timeMin)} and ${colors.blue(timeMax)}`));

  // TODO: support CSV
  const input = new (require(`./model/${process.env.INPUT}.js`))();
  const inputEvents = await input.getEventList(timeMin, timeMax);

  const jiraEvents = await require(`./input/${process.env.INPUT}.js`)(process.env.JIRA_STRATEGY, inputEvents);
  const jobcanEvents = await require(`./input/${process.env.INPUT}.js`)(process.env.JOBCAN_STRATEGY, inputEvents);

  if (output === 'JOBCAN') {
    jobcan.display(jobcanEvents);
  } else if (output === 'JIRA') {
    jira.display(jiraEvents);
  } else if (output === 'BOTH') {
    jira.display(jiraEvents);
    jobcan.display(jobcanEvents);
  }

  const question = `Do you want to persist the information into ${output === 'BOTH' ? 'JIRA and JOBCAN' : output}? (y/N) `;
  const accepted = ['y', 'Y', 'yes'];
  const shouldPersist = await askIfContinue(question, accepted);
  if (!shouldPersist) return;

  switch (output) {
    case 'JOBCAN':
      await jobcan.persist(jobcanEvents);
      break;
    case 'JIRA':
      await jira.persist(jiraEvents);
      break;
    case 'BOTH':
      await jira.persist(jiraEvents);
      await jobcan.persist(jobcanEvents);
    default:
      console.log('\n');
  }
}

exports.handler = async (event) => {
  try {
    // Retrieve start and end dates from the event object
    const startDate = event.startDate;
    const endDate = event.endDate;

    await main(startDate, endDate);
  } catch (error) {
    console.error(error);
  }
};
